# DIP Homework Assignment #1
# Name: 曾俊為
# ID >: r07922106
# email:champion8599@gmail.com
python prob0.py
python prob1.py  
python prob2.py
python bonus.py