# DIP Homework Assignment #2
# Name: 曾俊為
# ID >: r07922106
# email:champion8599@gmail.com
python prob1.py  
python prob2.py